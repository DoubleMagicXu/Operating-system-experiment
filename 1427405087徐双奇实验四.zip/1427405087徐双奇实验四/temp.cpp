#include<fstream>
#include<iostream>
using namespace std;
int main()
{
    ofstream f("/home/sqxu/Desktop/os/1427405087徐双奇实验四/temp.txt");
    //f<<"ff"<<endl;
    return 0;
}
